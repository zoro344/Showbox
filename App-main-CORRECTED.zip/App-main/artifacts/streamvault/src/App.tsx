import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Bookmark, Check, ChevronDown, ChevronLeft, CircleAlert, Clapperboard, ExternalLink, Film, Heart, History, Info, Library, ListFilter, Menu, Moon, Play, RotateCcw, Search, Settings as SettingsIcon, ShieldCheck, Sparkles, Sun, Tv, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, useParams } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { useVaultStorage, type PlaybackProgress, type WatchedItem } from '@/hooks/use-vault-storage';
import {
  ContentSource,
  ContentType,
  getGetContentDetailsQueryKey,
  getGetContentEpisodesQueryKey,
  getGetHomeFeedQueryKey,
  getGetPlaybackOptionsQueryKey,
  getSearchCatalogQueryKey,
  useGetContentDetails,
  useGetContentEpisodes,
  useGetHomeFeed,
  useGetPlaybackOptions,
  useSearchCatalog,
  type ContentDetail,
  type ContentItem,
  type Episode,
  type PlaybackOption,
  type ProviderRef,
} from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
type AnyItem = ContentItem | ContentDetail;

function sourceName(source?: string) {
  if (source === 'internet-archive') return 'Internet Archive';
  if (source === 'jikan') return 'MyAnimeList via Jikan';
  return 'TVmaze';
}
function typeName(type?: string) {
  return type ? type.charAt(0).toUpperCase() + type.slice(1) : 'Title';
}
function itemKey(item: Pick<ContentItem, 'source' | 'id'>) { return `${item.source}:${item.id}`; }
function watchKey(item: Pick<ContentItem, 'source' | 'id'>, episodeId?: string) {
  return episodeId ? `${itemKey(item)}:episode:${episodeId}` : itemKey(item);
}
function progressPosition(progress?: PlaybackProgress) {
  return progress?.position ?? 0;
}

function Poster({ item, className = '', wide = false }: { item: Partial<AnyItem>; className?: string; wide?: boolean }) {
  const image = wide ? item.backdropUrl : item.posterUrl;
  const [imageFailed, setImageFailed] = useState(false);
  useEffect(() => setImageFailed(false), [image]);
  return (
    <div className={`relative overflow-hidden bg-[hsl(var(--secondary))] ${className}`} data-testid={`poster-${item.id || 'fallback'}`}>
      {image && !imageFailed ? <img src={image} alt="" loading={wide ? 'eager' : 'lazy'} decoding="async" onError={() => setImageFailed(true)} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" /> : <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_25%,hsl(var(--accent)/.8),transparent_34%),linear-gradient(145deg,hsl(var(--secondary)),hsl(var(--foreground)))]"><Film className="absolute bottom-5 left-5 h-10 w-10 text-[hsl(var(--accent)/.8)]" /></div>}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[hsl(var(--foreground)/.75)] via-transparent to-transparent" />
    </div>
  );
}

function Mark({ small = false }: { small?: boolean }) {
  return <div className={`flex items-center gap-2 ${small ? 'text-sm' : ''}`}><span className="grid h-8 w-8 place-items-center rounded-[10px] bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"><Clapperboard className="h-4 w-4" /></span><span className="font-semibold tracking-[-.03em]">stream<span className="text-[hsl(var(--primary))]">vault</span></span></div>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const storage = useVaultStorage();
  const nav = [
    { href: '/', label: 'Discover', icon: Sparkles },
    { href: '/search', label: 'Search', icon: Search },
    { href: '/library', label: 'My library', icon: Library },
    { href: '/settings', label: 'Settings', icon: SettingsIcon },
  ];
  return <div className="grain min-h-[100dvh] bg-background">
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex h-[72px] max-w-[1440px] items-center gap-5 px-5 md:px-10">
        <Link href="/" className="shrink-0" data-testid="link-logo"><Mark /></Link>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Primary navigation">
          {nav.slice(0, 3).map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors hover:bg-muted ${location === href ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}><Icon className="h-4 w-4" />{label}</Link>)}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Link href="/search" className="hidden h-10 items-center gap-2 rounded-full border border-border bg-card px-4 text-sm text-muted-foreground transition-colors hover:border-[hsl(var(--primary)/.5)] hover:text-foreground sm:flex" data-testid="link-header-search"><Search className="h-4 w-4" />Find something to watch</Link>
          <button type="button" onClick={() => storage.setTheme(storage.theme === 'dark' ? 'light' : 'dark')} className="grid h-10 w-10 place-items-center rounded-full border border-border bg-card text-muted-foreground hover:text-foreground" data-testid="button-toggle-theme" aria-label="Toggle theme">{storage.theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}</button>
          <Link href="/settings" className="hidden h-10 w-10 place-items-center rounded-full border border-border bg-card text-muted-foreground hover:text-foreground sm:grid" data-testid="link-settings"><SettingsIcon className="h-4 w-4" /></Link>
        </div>
      </div>
    </header>
    <main>{children}</main>
    <nav className="safe-bottom fixed bottom-0 left-0 right-0 z-40 grid grid-cols-4 border-t border-border bg-card/95 px-3 pt-2 backdrop-blur-xl md:hidden" aria-label="Mobile navigation">
      {nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`} className={`flex min-h-14 flex-col items-center gap-1 text-[10px] font-medium ${location === href ? 'text-[hsl(var(--primary))]' : 'text-muted-foreground'}`}><Icon className="h-5 w-5" />{label}</Link>)}
    </nav>
  </div>;
}

function LoadingState({ label = 'Opening the vault' }: { label?: string }) {
  return <div className="mx-auto max-w-[1440px] px-5 py-12 md:px-10"><div className="mb-10 h-12 w-72 animate-pulse rounded-lg bg-muted" /><div className="grid grid-cols-2 gap-4 md:grid-cols-5">{[1, 2, 3, 4, 5].map((n) => <div key={n} className="animate-pulse"><div className="aspect-[2/3] rounded-xl bg-muted" /><div className="mt-3 h-4 w-3/4 rounded bg-muted" /></div>)}</div><p className="mt-8 font-mono-ui text-xs uppercase tracking-[.16em] text-muted-foreground">{label}...</p></div>;
}
function ErrorState({ onRetry, message }: { onRetry?: () => void; message?: string }) {
  return <div className="mx-auto flex max-w-xl flex-col items-center px-5 py-24 text-center"><div className="mb-5 grid h-14 w-14 place-items-center rounded-full bg-[hsl(var(--primary)/.12)] text-[hsl(var(--primary))]"><CircleAlert /></div><h2 className="font-display text-4xl">The projector blinked.</h2><p className="mt-3 text-muted-foreground">We couldn't reach the catalog right now. Your saved library is still safe.</p>{message && <p className="mt-3 max-w-lg rounded-xl border border-border bg-card p-3 text-left text-xs text-muted-foreground">{message}</p>}{onRetry && <button type="button" onClick={onRetry} className="mt-7 flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="button-retry"><RotateCcw className="h-4 w-4" />Try again</button>}</div>;
}
function EmptyState({ title, copy, action }: { title: string; copy: string; action?: ReactNode }) {
  return <div className="rounded-2xl border border-dashed border-border bg-card/50 px-6 py-16 text-center"><Bookmark className="mx-auto h-8 w-8 text-[hsl(var(--primary))]" /><h3 className="mt-4 font-display text-3xl">{title}</h3><p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">{copy}</p>{action}</div>;
}

function ItemCard({ item, index = 0, onFavorite, favorite = false }: { item: ContentItem; index?: number; onFavorite?: (item: ContentItem) => void; favorite?: boolean }) {
  return <div className="group animate-vault-in min-w-[148px] max-w-[190px] flex-1" style={{ animationDelay: `${index * 65}ms` }}>
    <Link href={`/title/${item.source}/${item.id}`} className="block" data-testid={`link-title-${item.id}`}>
      <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-border/80 bg-muted shadow-sm transition-transform duration-300 group-hover:-translate-y-1.5"><Poster item={item} className="h-full w-full" /><div className="absolute right-2 top-2 rounded-full bg-[hsl(var(--foreground)/.72)] px-2 py-1 font-mono-ui text-[9px] uppercase tracking-wider text-[hsl(var(--background))]">{sourceName(item.source)}</div>{item.rating && <div className="absolute bottom-2 left-2 rounded-full bg-[hsl(var(--accent))] px-2 py-1 font-mono-ui text-[10px] text-[hsl(var(--accent-foreground))]">{item.rating.toFixed(1)}</div>}</div>
      <h3 className="mt-3 line-clamp-1 text-sm font-semibold">{item.title}</h3>
      <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{item.year || 'Undated'} · {typeName(item.type)}</p>
    </Link>
    {onFavorite && <button type="button" onClick={() => onFavorite(item)} className={`mt-2 flex items-center gap-1 text-xs ${favorite ? 'text-[hsl(var(--primary))]' : 'text-muted-foreground hover:text-foreground'}`} data-testid={`button-favorite-${item.id}`}><Heart className={`h-3.5 w-3.5 ${favorite ? 'fill-current' : ''}`} />{favorite ? 'In library' : 'Save'}</button>}
  </div>;
}

function Transparency({ providers }: { providers: ProviderRef[] }) {
  return <section className="border-y border-border bg-secondary py-10 text-secondary-foreground"><div className="mx-auto max-w-[1440px] px-5 md:px-10"><div className="grid gap-6 md:grid-cols-[1fr_2fr] md:items-center"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-accent">Source notes</p><h2 className="mt-2 font-display text-4xl">Every title has a paper trail.</h2></div><div className="grid gap-3 sm:grid-cols-2">{providers.slice(0, 4).map((provider) => <a key={`${provider.source}-${provider.name}`} href={provider.url} target="_blank" rel="noreferrer" className="group rounded-xl border border-secondary-foreground/15 bg-secondary-foreground/5 p-4 transition-colors hover:bg-secondary-foreground/10" data-testid={`link-provider-${provider.source}`}><div className="flex items-start justify-between"><ShieldCheck className="h-5 w-5 text-accent" /><ExternalLink className="h-4 w-4 opacity-50 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></div><p className="mt-5 text-sm font-semibold">{provider.name}</p><p className="mt-1 text-xs text-secondary-foreground/65">{provider.permission}</p></a>)}</div></div></div></section>;
}

function ContinueWatching({ items, progress }: { items: WatchedItem[]; progress: Record<string, PlaybackProgress> }) {
  const itemsWithProgress = items.filter((item) => {
    const entry = progress[watchKey(item, item.episodeId)];
    if (!entry || progressPosition(entry) <= 0) return false;
    return !item.duration || progressPosition(entry) < item.duration * 60;
  }).slice(0, 5);
  if (!itemsWithProgress.length) return null;
  return <section className="mb-14" data-testid="section-continue-watching"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Pick up where you left off</p><h2 className="mt-1 font-display text-4xl">Continue watching</h2></div><History className="h-5 w-5 text-muted-foreground" /></div><div className="space-y-3">{itemsWithProgress.map((item) => <WatchedRow key={watchKey(item, item.episodeId)} item={item} progress={progress[watchKey(item, item.episodeId)]} />)}</div></section>;
}

function Home() {
  const feed = useGetHomeFeed({ query: { queryKey: getGetHomeFeedQueryKey() } });
  const storage = useVaultStorage();
  if (feed.isLoading) return <LoadingState />;
  if (feed.isError || !feed.data) return <ErrorState onRetry={() => feed.refetch()} message={feed.error instanceof Error ? feed.error.message : undefined} />;
  const home = feed.data;
  const featured = home.featured;
  return <div>
    <section className="relative isolate min-h-[560px] overflow-hidden bg-[hsl(var(--foreground))] text-[hsl(var(--background))]"><Poster item={featured} wide className="absolute inset-0 -z-10 h-full w-full opacity-50 animate-vault-drift" /><div className="absolute inset-0 -z-10 bg-gradient-to-r from-[hsl(var(--foreground))] via-[hsl(var(--foreground)/.82)] to-transparent" /><div className="mx-auto flex min-h-[560px] max-w-[1440px] items-end px-5 pb-14 pt-20 md:px-10 md:pb-20"><div className="max-w-2xl animate-vault-in"><p className="font-mono-ui text-[10px] uppercase tracking-[.23em] text-accent">Tonight's signal · Featured</p><h1 className="mt-5 text-balance font-display text-6xl leading-[.88] sm:text-7xl md:text-8xl">{featured.title}</h1><div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-[hsl(var(--background)/.75)]"><span>{featured.year || 'Archive'} </span><span className="h-1 w-1 rounded-full bg-accent" /><span>{typeName(featured.type)}</span><span className="h-1 w-1 rounded-full bg-accent" /><span>{featured.genres.slice(0, 2).join(' / ') || 'Curated selection'}</span></div><p className="mt-5 max-w-xl text-sm leading-6 text-[hsl(var(--background)/.72)]">{featured.description}</p><div className="mt-8 flex flex-wrap gap-3"><Link href={`/title/${featured.source}/${featured.id}`} className="flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5" data-testid="link-featured-details"><Info className="h-4 w-4" />Open title</Link><button type="button" onClick={() => storage.toggleFavorite(featured)} className="flex items-center gap-2 rounded-full border border-[hsl(var(--background)/.3)] px-5 py-3 text-sm font-semibold transition-colors hover:bg-[hsl(var(--background)/.12)]" data-testid="button-featured-save"><Heart className="h-4 w-4" />Save to library</button></div></div></div></section>
     <div className="mx-auto max-w-[1440px] px-5 py-14 md:px-10">{storage.watched.length > 0 && <ContinueWatching items={storage.watched} progress={storage.progress} />} {home.rows.map((row, i) => <section key={row.title} className="mb-14"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Collection {String(i + 1).padStart(2, '0')}</p><h2 className="mt-1 font-display text-4xl">{row.title}</h2></div><Link href="/search" className="hidden items-center gap-1 text-sm text-muted-foreground hover:text-foreground sm:flex" data-testid={`link-row-search-${i}`}>Browse all <ChevronRightIcon /></Link></div><div className="vault-row no-scrollbar flex gap-4 overflow-x-auto pb-2 md:gap-5">{row.items.map((item, index) => <ItemCard key={itemKey(item)} item={item} index={index} onFavorite={storage.toggleFavorite} favorite={storage.favorites.some((x) => itemKey(x) === itemKey(item))} />)}</div></section>)}</div>
    <Transparency providers={home.sources} />
    <section className="mx-auto max-w-[1440px] px-5 py-20 text-center md:px-10"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">A better kind of streaming</p><h2 className="mx-auto mt-4 max-w-2xl font-display text-5xl leading-none md:text-6xl">No mystery links.<br /><i>No noise.</i></h2><p className="mx-auto mt-5 max-w-lg text-sm leading-6 text-muted-foreground">StreamVault is a discovery layer for the things you can watch legally. Know the source, then choose how to watch.</p></section>
  </div>;
}
function ChevronRightIcon() { return <span aria-hidden="true">→</span>; }

function SearchPage() {
  const storage = useVaultStorage();
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState('');
  const [type, setType] = useState('');
  const [genre, setGenre] = useState('');
  const params = useMemo(() => ({ query: submitted || ' ' , ...(type ? { type: type as typeof ContentType[keyof typeof ContentType] } : {}), ...(genre ? { genre } : {}) }), [submitted, type, genre]);
  const search = useSearchCatalog(params, { query: { enabled: Boolean(submitted.trim()), queryKey: getSearchCatalogQueryKey(params) } });
  const submit = (value = query) => { const clean = value.trim(); if (!clean) return; setSubmitted(clean); storage.addSearch(clean); };
  return <div className="mx-auto max-w-[1440px] px-5 py-12 pb-28 md:px-10 md:py-16"><div className="max-w-3xl animate-vault-in"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">The catalog index</p><h1 className="mt-3 font-display text-6xl leading-none md:text-8xl">Find your<br /><i>next room.</i></h1><form className="mt-10 flex gap-2" onSubmit={(e) => { e.preventDefault(); submit(); }}><div className="relative flex-1"><Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Film, series, feeling..." className="h-14 w-full rounded-2xl border border-border bg-card pl-12 pr-4 outline-none ring-primary transition focus:ring-2" data-testid="input-search" /></div><button type="submit" className="h-14 rounded-2xl bg-primary px-6 font-semibold text-primary-foreground" data-testid="button-search">Search</button></form></div>
    {!submitted && <div className="mt-14 grid gap-12 md:grid-cols-[1fr_2fr]"><div><h2 className="font-display text-3xl">Start with a trail</h2><p className="mt-2 text-sm text-muted-foreground">Your recent searches stay on this device only.</p></div><div>{storage.history.length ? <div className="flex flex-wrap gap-2">{storage.history.map((item) => <button type="button" key={item} onClick={() => { setQuery(item); submit(item); }} className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2.5 text-sm hover:border-primary" data-testid={`button-history-${item}`}><History className="h-3.5 w-3.5 text-primary" />{item}</button>)}<button type="button" onClick={storage.clearHistory} className="ml-2 text-xs text-muted-foreground underline" data-testid="button-clear-history">Clear history</button></div> : <p className="text-sm text-muted-foreground">No searches yet. Try “midnight”, “comedy”, or a favorite director.</p>}</div></div>}
    {submitted && <div className="mt-12"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-5"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Search results</p><h2 className="mt-1 font-display text-4xl">For “{submitted}”</h2></div><div className="flex gap-2"><select value={type} onChange={(e) => setType(e.target.value)} className="h-10 rounded-full border border-border bg-card px-4 text-sm" data-testid="select-type"><option value="">All types</option><option value="movie">Movies</option><option value="series">Series</option><option value="documentary">Documentaries</option><option value="short">Shorts</option></select><input value={genre} onChange={(e) => setGenre(e.target.value)} placeholder="Genre" className="h-10 w-28 rounded-full border border-border bg-card px-4 text-sm outline-none focus:ring-2 focus:ring-primary" data-testid="input-genre" /></div></div>{search.isLoading && <LoadingState label="Searching the archives" />}{search.isError && <ErrorState onRetry={() => search.refetch()} message={search.error instanceof Error ? search.error.message : undefined} />}{search.data && !search.data.length && <div className="mt-8"><EmptyState title="No title in this reel." copy="Try a broader title, a different genre, or search without the filter." action={<button type="button" onClick={() => { setType(''); setGenre(''); }} className="mt-6 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="button-reset-filters">Reset filters</button>} /></div>}{search.data && search.data.length > 0 && <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-3 lg:grid-cols-5">{search.data.map((item, index) => <ItemCard key={itemKey(item)} item={item} index={index} onFavorite={storage.toggleFavorite} favorite={storage.favorites.some((x) => itemKey(x) === itemKey(item))} />)}</div>}</div>}
  </div>;
}

function LegacyDetailPage() {
  const params = useParams<{ source: string; id: string }>();
  const source = (params.source || 'tvmaze') as ContentSource;
  const id = params.id || '';
  const storage = useVaultStorage();
  const details = useGetContentDetails(source, id, { query: { queryKey: getGetContentDetailsQueryKey(source, id) } });
  const detail = details.data;
  const [season, setSeason] = useState(1);
  const episodes = useGetContentEpisodes(source, id, { season }, { query: { enabled: Boolean(detail?.type === 'series'), queryKey: getGetContentEpisodesQueryKey(source, id, { season }) } });
  if (details.isLoading) return <LoadingState label="Developing title card" />;
  if (details.isError || !detail) return <ErrorState onRetry={() => details.refetch()} message={details.error instanceof Error ? details.error.message : undefined} />;
  const saved = storage.favorites.some((x) => itemKey(x) === itemKey(detail));
  const isSeries = detail.type === 'series';
  return <div className="pb-20"><section className="relative isolate overflow-hidden bg-[hsl(var(--foreground))] text-[hsl(var(--background))]"><Poster item={detail} wide className="absolute inset-0 -z-10 h-full min-h-[640px] w-full opacity-35" /><div className="absolute inset-0 -z-10 bg-gradient-to-t from-[hsl(var(--foreground))] via-[hsl(var(--foreground)/.78)] to-[hsl(var(--foreground)/.35)]" /><div className="mx-auto max-w-[1440px] px-5 pb-12 pt-10 md:px-10 md:pt-16"><Link href="/" className="mb-12 flex items-center gap-2 text-sm text-[hsl(var(--background)/.7)] hover:text-[hsl(var(--background))]" data-testid="link-back"><ChevronLeft className="h-4 w-4" />Back to discovery</Link><div className="max-w-3xl animate-vault-in"><div className="flex flex-wrap gap-2 text-[10px] font-mono-ui uppercase tracking-[.15em] text-accent"><span>{sourceName(detail.source)}</span><span>·</span><span>{typeName(detail.type)}</span><span>·</span><span>{detail.year || 'Archive'}</span></div><h1 className="mt-5 font-display text-7xl leading-[.86] md:text-9xl">{detail.title}</h1><p className="mt-7 max-w-2xl text-base leading-7 text-[hsl(var(--background)/.76)]">{detail.description}</p><div className="mt-8 flex flex-wrap gap-3"><Link href={`/watch/${detail.source}/${detail.id}`} className="flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="link-watch-title"><Play className="h-4 w-4 fill-current" />Find a way to watch</Link><button type="button" onClick={() => storage.toggleFavorite(detail)} className="flex items-center gap-2 rounded-full border border-[hsl(var(--background)/.3)] px-5 py-3 text-sm font-semibold" data-testid="button-toggle-favorite">{saved ? <Check className="h-4 w-4" /> : <Heart className="h-4 w-4" />} {saved ? 'Saved in library' : 'Save to library'}</button></div></div></div></section><div className="mx-auto grid max-w-[1440px] gap-14 px-5 pt-14 md:grid-cols-[1.4fr_.6fr] md:px-10"><div>{isSeries && <section><div className="flex items-center justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Episode guide</p><h2 className="mt-1 font-display text-4xl">Choose a chapter</h2></div><select value={season} onChange={(e) => setSeason(Number(e.target.value))} className="rounded-full border border-border bg-card px-4 py-2 text-sm" data-testid="select-season">{detail.seasons.map((s) => <option key={s} value={s}>Season {s}</option>)}</select></div><div className="mt-6 space-y-3">{episodes.isLoading ? [1, 2, 3].map((n) => <div key={n} className="h-24 animate-pulse rounded-xl bg-muted" />) : episodes.data?.map((episode) => <EpisodeRow key={episode.id} episode={episode} content={detail} />)}</div></section>}<section className={isSeries ? 'mt-14' : ''}><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">The paper trail</p><h2 className="mt-1 font-display text-4xl">About this title</h2><div className="mt-5 grid gap-5 text-sm leading-6 text-muted-foreground sm:grid-cols-2"><p><strong className="text-foreground">Genres</strong><br />{detail.genres.join(' · ') || 'Not catalogued'}</p><p><strong className="text-foreground">Cast</strong><br />{detail.cast.join(' · ') || 'Not listed'}</p><p><strong className="text-foreground">Crew</strong><br />{detail.crew.join(' · ') || 'Not listed'}</p><p><strong className="text-foreground">Catalog source</strong><br />{sourceName(detail.source)} · {detail.provider.permission}</p></div></section></div><aside><div className="sticky top-24 rounded-2xl border border-border bg-card p-5"><p className="flex items-center gap-2 text-xs font-semibold"><ShieldCheck className="h-4 w-4 text-primary" />Transparent sourcing</p><p className="mt-3 text-sm leading-6 text-muted-foreground">Playback choices are returned by approved providers. StreamVault never fabricates media URLs or bypasses provider controls.</p><div className="mt-5 space-y-2">{detail.sources.map((provider) => <a key={provider.url} href={provider.url} target="_blank" rel="noreferrer" className="flex items-center justify-between rounded-xl bg-muted px-3 py-3 text-xs font-medium hover:bg-[hsl(var(--accent)/.3)]" data-testid={`link-detail-source-${provider.source}`}><span>{provider.name}</span><ExternalLink className="h-3.5 w-3.5 text-muted-foreground" /></a>)}</div></div></aside></div></div>;
}
function EpisodeRow({ episode, content }: { episode: Episode; content: ContentDetail }) {
  return <Link href={`/watch/${content.source}/${content.id}?season=${episode.season}&episode=${episode.number}`} className="group flex gap-4 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary" data-testid={`link-episode-${episode.id}`}><div className="aspect-video w-28 shrink-0 overflow-hidden rounded-lg bg-muted sm:w-40">{episode.thumbnailUrl ? <img src={episode.thumbnailUrl} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-primary"><Play className="h-5 w-5" /></div>}</div><div className="min-w-0 py-1"><p className="font-mono-ui text-[10px] uppercase tracking-widest text-primary">Episode {episode.number}</p><h3 className="mt-1 truncate font-semibold">{episode.title}</h3><p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">{episode.description}</p></div><ChevronRightIcon /></Link>;
}

function PlaybackVideo({ active, item, episode, storage, onError }: { active: PlaybackOption; item: ContentDetail; episode?: Episode; storage: ReturnType<typeof useVaultStorage>; onError: () => void }) {
  const [ready, setReady] = useState(false);
  const restored = useRef(false);
  const key = watchKey(item, episode?.id);
  const saved = storage.progress[key];
  const preferredTrack = active.subtitles?.find((track) => storage.settings.language === 'Original' || track.language.toLowerCase().startsWith(storage.settings.language.toLowerCase()));
  useEffect(() => {
    setReady(false);
    restored.current = false;
  }, [active.id, key]);
  return <div className="relative h-full w-full"><video key={active.id} controls autoPlay={storage.settings.autoplay} preload="metadata" poster={item.backdropUrl ?? item.posterUrl ?? undefined} className={`h-full w-full object-contain transition-opacity ${ready ? 'opacity-100' : 'opacity-0'}`} onLoadedMetadata={(event) => { const video = event.currentTarget; const position = saved?.position ?? 0; if (!restored.current && position > 0 && (!video.duration || position < video.duration - 3)) video.currentTime = position; restored.current = true; setReady(true); }} onError={onError} onTimeUpdate={(event) => storage.setWatchProgress(key, event.currentTarget.currentTime, { episodeId: episode?.id, season: episode?.season, episodeNumber: episode?.number, duration: Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : undefined })} data-testid="video-player"><source src={active.url} type={active.mimeType ?? undefined} />{active.subtitles?.map((track) => <track key={track.url} kind="subtitles" src={track.url} srcLang={track.language} label={track.label} default={track.url === preferredTrack?.url} />)}</video>{!ready && <div className="absolute inset-0 grid place-items-center text-[hsl(var(--background))]"><div className="text-center"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-[hsl(var(--background)/.25)] border-t-accent" /><p className="mt-3 text-xs uppercase tracking-widest text-[hsl(var(--background)/.65)]">Preparing playback</p></div></div>}</div>;
}

function MovieAvailability({ source, id }: { source: ContentSource; id: string }) {
  const details = useGetContentDetails(source, id, { query: { queryKey: getGetContentDetailsQueryKey(source, id) } });
  const options = useGetPlaybackOptions(source, id, {}, { query: { queryKey: getGetPlaybackOptionsQueryKey(source, id, {}) } });
  if (details.data?.type !== 'movie' || options.isLoading || !options.data?.length) return null;
  return <section className="mx-auto max-w-[1440px] px-5 pb-16 md:px-10" data-testid="section-movie-availability"><div className="rounded-2xl border border-border bg-card p-5 md:p-7"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Authorized viewing options</p><h2 className="mt-1 font-display text-4xl">Choose a route</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">These options come directly from the configured provider. StreamVault does not infer rights or extract hidden media URLs.</p></div><ShieldCheck className="h-6 w-6 text-primary" /></div><div className="mt-6 grid gap-3 sm:grid-cols-2">{options.data.map((option) => option.kind === 'official-page' ? <a key={option.id} href={option.provider.url} target="_blank" rel="noreferrer" className="rounded-xl border border-border p-4 hover:border-primary" data-testid={`link-movie-official-${option.id}`}><div className="flex items-center justify-between gap-3"><span className="font-semibold">{option.label}</span><ExternalLink className="h-4 w-4 text-muted-foreground" /></div><p className="mt-2 text-xs leading-5 text-muted-foreground">{option.licenseNote}</p><p className="mt-3 text-xs font-semibold text-primary">Open Official Source</p></a> : <Link key={option.id} href={`/watch/${source}/${id}`} className="rounded-xl border border-border p-4 hover:border-primary" data-testid={`link-movie-play-${option.id}`}><div className="flex items-center justify-between gap-3"><span className="font-semibold">{option.label}</span><Play className="h-4 w-4 text-primary" /></div><p className="mt-2 text-xs leading-5 text-muted-foreground">{option.licenseNote}</p><p className="mt-3 text-xs font-semibold text-primary">Open authorized player</p></Link>)}</div></div></section>;
}

function DetailPage() {
  const params = useParams<{ source: string; id: string }>();
  const source = (params.source || 'tvmaze') as ContentSource;
  const id = params.id || '';
  return <><LegacyDetailPage /><MovieAvailability source={source} id={id} /></>;
}

function LegacyWatchPage() {
  const params = useParams<{ source: string; id: string }>();
  const source = (params.source || 'tvmaze') as ContentSource;
  const id = params.id || '';
  const [search] = useState(() => new URLSearchParams(window.location.search));
  const season = Number(search.get('season') || 1);
  const episode = Number(search.get('episode') || 1);
  const storage = useVaultStorage();
  const options = useGetPlaybackOptions(source, id, { season, ...(search.get('episode') ? { episode } : {}) }, { query: { queryKey: getGetPlaybackOptionsQueryKey(source, id, { season, ...(search.get('episode') ? { episode } : {}) }) } });
  const details = useGetContentDetails(source, id, { query: { queryKey: getGetContentDetailsQueryKey(source, id) } });
  const [selected, setSelected] = useState<PlaybackOption | null>(null);
  const [playerError, setPlayerError] = useState(false);
  useEffect(() => { if (options.data?.[0]) { setSelected(options.data[0]); setPlayerError(false); } }, [options.data]);
  useEffect(() => { if (details.data) storage.markWatched(details.data); }, [details.data]);
  if (options.isLoading || details.isLoading) return <LoadingState label="Checking approved ways to watch" />;
  if (options.isError || details.isError || !details.data) return <ErrorState onRetry={() => options.refetch()} message={options.error instanceof Error ? options.error.message : details.error instanceof Error ? details.error.message : undefined} />;
  const active = selected || options.data?.[0];
  return <div className="mx-auto max-w-[1440px] px-5 py-10 pb-28 md:px-10"><Link href={`/title/${source}/${id}`} className="mb-8 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground" data-testid="link-watch-back"><ChevronLeft className="h-4 w-4" />Back to title</Link><div className="grid gap-8 lg:grid-cols-[1.6fr_.7fr]"><div><div className="relative aspect-video overflow-hidden rounded-2xl border border-border bg-[hsl(var(--foreground))]">{active?.kind === 'direct' && !playerError && <video controls className="h-full w-full" src={active.url} onError={() => setPlayerError(true)} onTimeUpdate={(e) => storage.setWatchProgress(itemKey(details.data!), e.currentTarget.currentTime)} data-testid="video-player" />}{active?.kind === 'embed' && active.isEmbeddable && <iframe title={active.label} src={active.url} className="h-full w-full" allowFullScreen data-testid="iframe-player" />}{(playerError || !active || active.kind === 'official-page' || (active.kind === 'embed' && !active.isEmbeddable)) && <div className="flex h-full flex-col items-center justify-center px-6 text-center text-[hsl(var(--background))]"><ShieldCheck className="h-9 w-9 text-accent" /><h1 className="mt-4 font-display text-4xl">{playerError ? 'This format could not play here' : active ? 'Continue at the official source' : 'No player in this room'}</h1><p className="mt-3 max-w-md text-sm text-[hsl(var(--background)/.65)]">{playerError ? 'The source authorized this file, but this browser does not support its format. Open the provider page to continue.' : active?.licenseNote || 'This provider has not supplied an embeddable player. The official page is the safest way to continue.'}</p>{active && <a href={active.provider.url} target="_blank" rel="noreferrer" className="mt-6 flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="link-official-source"><ExternalLink className="h-4 w-4" />Open official page</a>}</div>}</div><div className="mt-5"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Now showing</p><h1 className="mt-2 font-display text-4xl">{details.data.title}{search.get('episode') ? <span className="text-muted-foreground"> · S{season} E{episode}</span> : ''}</h1></div></div><aside><div className="rounded-2xl border border-border bg-card p-5"><p className="flex items-center gap-2 font-semibold"><ListFilter className="h-4 w-4 text-primary" />Approved ways to watch</p><p className="mt-2 text-xs leading-5 text-muted-foreground">Select a route. Permission labels are provided by the source, not inferred by StreamVault.</p><div className="mt-5 space-y-2">{options.data?.map((option) => <button key={option.id} type="button" onClick={() => { setSelected(option); setPlayerError(false); }} className={`w-full rounded-xl border p-3 text-left transition-colors ${active?.id === option.id ? 'border-primary bg-[hsl(var(--primary)/.08)]' : 'border-border hover:border-primary/50'}`} data-testid={`button-playback-${option.id}`}><div className="flex items-center justify-between"><span className="text-sm font-semibold">{option.label}</span><span className="font-mono-ui text-[9px] uppercase tracking-widest text-primary">{option.kind}</span></div><p className="mt-1 text-xs text-muted-foreground">{option.provider.name}</p></button>)}</div></div></aside></div></div>;
}

function WatchPage() {
  const params = useParams<{ source: string; id: string }>();
  const source = (params.source || 'tvmaze') as ContentSource;
  const id = params.id || '';
  const [search] = useState(() => new URLSearchParams(window.location.search));
  const hasEpisode = Boolean(search.get('episode'));
  const season = Number(search.get('season') || 1);
  const episodeNumber = Number(search.get('episode') || 1);
  const storage = useVaultStorage();
  const playbackQuery = { season, ...(hasEpisode ? { episode: episodeNumber } : {}) };
  const options = useGetPlaybackOptions(source, id, playbackQuery, { query: { queryKey: getGetPlaybackOptionsQueryKey(source, id, playbackQuery) } });
  const details = useGetContentDetails(source, id, { query: { queryKey: getGetContentDetailsQueryKey(source, id) } });
  const episodes = useGetContentEpisodes(source, id, { season }, { query: { enabled: hasEpisode, queryKey: getGetContentEpisodesQueryKey(source, id, { season }) } });
  const currentEpisode = episodes.data?.find((entry) => entry.number === episodeNumber);
  const [selected, setSelected] = useState<PlaybackOption | null>(null);
  const [playerError, setPlayerError] = useState(false);
  const preferredOption = options.data?.find((option) => storage.settings.quality === 'auto' || option.label.toLowerCase().includes(storage.settings.quality.toLowerCase())) ?? options.data?.[0];
  useEffect(() => {
    if (preferredOption) {
      setSelected(preferredOption);
      setPlayerError(false);
    }
  }, [preferredOption?.id]);
  useEffect(() => {
    if (details.data) storage.markWatched(details.data, currentEpisode ? { episodeId: currentEpisode.id, season: currentEpisode.season, episodeNumber: currentEpisode.number } : undefined);
  }, [details.data, currentEpisode?.id]);
  if (options.isLoading || details.isLoading) return <LoadingState label="Checking approved ways to watch" />;
  if (options.isError || details.isError || !details.data) return <ErrorState onRetry={() => options.refetch()} message={options.error instanceof Error ? options.error.message : details.error instanceof Error ? details.error.message : undefined} />;
  const active = selected || options.data?.[0];
  const currentIndex = episodes.data?.findIndex((entry) => entry.id === currentEpisode?.id) ?? -1;
  const previousEpisode = currentIndex > 0 ? episodes.data?.[currentIndex - 1] : undefined;
  const nextEpisode = currentIndex >= 0 ? episodes.data?.[currentIndex + 1] : undefined;
  return <div className="mx-auto max-w-[1440px] px-5 py-10 pb-28 md:px-10"><Link href={`/title/${source}/${id}`} className="mb-8 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground" data-testid="link-watch-back"><ChevronLeft className="h-4 w-4" />Back to title</Link><div className="grid gap-8 lg:grid-cols-[1.6fr_.7fr]"><div><div className="relative aspect-video overflow-hidden rounded-2xl border border-border bg-[hsl(var(--foreground))]">{active?.kind === 'direct' && !playerError && <PlaybackVideo active={active} item={details.data} episode={currentEpisode} storage={storage} onError={() => setPlayerError(true)} />}{active?.kind === 'embed' && active.isEmbeddable && <iframe title={active.label} src={active.url} className="h-full w-full" allow="fullscreen; autoplay; encrypted-media; picture-in-picture" allowFullScreen data-testid="iframe-player" />}{(playerError || !active || active.kind === 'official-page' || (active.kind === 'embed' && !active.isEmbeddable)) && <div className="flex h-full flex-col items-center justify-center px-6 text-center text-[hsl(var(--background))]"><ShieldCheck className="h-9 w-9 text-accent" /><h1 className="mt-4 font-display text-4xl">{playerError ? 'This format could not play here' : active ? 'Continue at the official source' : 'No player in this room'}</h1><p className="mt-3 max-w-md text-sm leading-6 text-[hsl(var(--background)/.65)]">{playerError ? 'The source authorized this file, but this browser does not support its format. Open the provider page to continue.' : 'Playback is provided by the official source.'}</p>{active && <a href={active.provider.url} target="_blank" rel="noreferrer" className="mt-6 flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="link-official-source"><ExternalLink className="h-4 w-4" />Open Official Source</a>}</div>}</div><div className="mt-5"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Now showing</p><h1 className="mt-2 font-display text-4xl">{details.data.title}{hasEpisode ? <span className="text-muted-foreground"> · S{season} E{episodeNumber}</span> : ''}</h1>{currentEpisode && <div className="mt-5 flex flex-wrap gap-2">{previousEpisode && <Link href={`/watch/${source}/${id}?season=${previousEpisode.season}&episode=${previousEpisode.number}`} className="rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary" data-testid="link-previous-episode">← Previous</Link>}{nextEpisode && <Link href={`/watch/${source}/${id}?season=${nextEpisode.season}&episode=${nextEpisode.number}`} className="rounded-full border border-border px-4 py-2 text-xs font-semibold hover:border-primary" data-testid="link-next-episode">Next →</Link>}</div>}</div></div><aside><div className="rounded-2xl border border-border bg-card p-5"><p className="flex items-center gap-2 font-semibold"><ListFilter className="h-4 w-4 text-primary" />Approved ways to watch</p><p className="mt-2 text-xs leading-5 text-muted-foreground">Select a route. Permission labels are provided by the source, not inferred by StreamVault.</p><div className="mt-5 space-y-2">{options.data?.map((option) => <button key={option.id} type="button" onClick={() => { setSelected(option); setPlayerError(false); }} className={`w-full rounded-xl border p-3 text-left transition-colors ${active?.id === option.id ? 'border-primary bg-[hsl(var(--primary)/.08)]' : 'border-border hover:border-primary/50'}`} data-testid={`button-playback-${option.id}`}><div className="flex items-center justify-between gap-3"><span className="text-sm font-semibold">{option.label}</span><span className="shrink-0 font-mono-ui text-[9px] uppercase tracking-widest text-primary">{option.kind}</span></div><p className="mt-1 text-xs text-muted-foreground">{option.provider.name}</p><p className="mt-2 text-[11px] leading-4 text-muted-foreground">{option.licenseNote}</p></button>)}</div></div></aside></div></div>;
}

function LegacyLibraryPage() {
  const storage = useVaultStorage();
  return <div className="mx-auto max-w-[1440px] px-5 py-12 pb-28 md:px-10 md:py-16"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Your private cinema journal</p><h1 className="mt-3 font-display text-7xl leading-none">My library</h1><div className="mt-14"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Saved for later</p><h2 className="mt-1 font-display text-4xl">Favorites</h2></div><span className="font-mono-ui text-xs text-muted-foreground">{storage.favorites.length} titles</span></div>{storage.favorites.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-4 lg:grid-cols-6">{storage.favorites.map((item, i) => <ItemCard key={itemKey(item)} item={item} index={i} onFavorite={storage.toggleFavorite} favorite />)}</div> : <EmptyState title="Your shelves are quiet." copy="Save titles from discovery and they'll stay here, locally on this device." action={<Link href="/search" className="mt-6 inline-flex rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="link-library-search">Find something</Link>} />}</div><div className="mt-20"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">A little unfinished</p><h2 className="mt-1 font-display text-4xl">Recently watched</h2></div><History className="h-5 w-5 text-muted-foreground" /></div>{storage.watched.length ? <div className="space-y-3">{storage.watched.slice(0, 5).map((item) => <WatchedRow key={itemKey(item)} item={item} progress={storage.progress[itemKey(item)] || 0} />)}</div> : <p className="rounded-xl border border-dashed border-border p-8 text-sm text-muted-foreground">Your watch history will appear here after you start a title.</p>}</div></div>;
}
function WatchedRow({ item, progress, onRemove }: { item: WatchedItem; progress?: PlaybackProgress; onRemove?: (item: WatchedItem) => void }) {
  const position = progressPosition(progress);
  const percent = item.duration ? Math.min(100, (position / (item.duration * 60)) * 100) : null;
  const destination = item.episodeId
    ? `/watch/${item.source}/${item.id}?season=${item.season ?? 1}&episode=${item.episodeNumber ?? 1}`
    : `/watch/${item.source}/${item.id}`;
  return <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 hover:border-primary"><Link href={destination} className="flex min-w-0 flex-1 items-center gap-4" data-testid={`link-watched-${item.id}${item.episodeId ? `-${item.episodeId}` : ''}`}><div className="h-16 w-24 shrink-0 overflow-hidden rounded-lg"><Poster item={item} className="h-full w-full" /></div><div className="min-w-0 flex-1"><h3 className="truncate font-semibold">{item.title}{item.episodeNumber ? <span className="text-muted-foreground"> · S{item.season} E{item.episodeNumber}</span> : ''}</h3><p className="mt-1 text-xs text-muted-foreground">{sourceName(item.source)} · {item.year || 'Archive'}</p><div className="mt-2 h-1 overflow-hidden rounded-full bg-muted">{percent !== null && <div className="h-full bg-primary" style={{ width: `${percent}%` }} />}</div><p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">{percent !== null ? `${Math.round(percent)}% watched` : position > 0 ? 'Progress saved' : 'Not started'}</p></div><ChevronRightIcon /></Link>{onRemove && <button type="button" onClick={() => onRemove(item)} className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground" aria-label={`Remove ${item.title} from watch history`} data-testid={`button-remove-watched-${item.id}`}><X className="h-4 w-4" /></button>}</div>;
}

function LibraryPage() {
  const storage = useVaultStorage();
  const continueItems = storage.watched.filter((item) => {
    const entry = storage.progress[watchKey(item, item.episodeId)];
    return Boolean(entry && progressPosition(entry) > 0 && (!item.duration || progressPosition(entry) < item.duration * 60));
  });
  return <div className="mx-auto max-w-[1440px] px-5 py-12 pb-28 md:px-10 md:py-16"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Your private cinema journal</p><div className="flex flex-wrap items-end justify-between gap-4"><h1 className="mt-3 font-display text-7xl leading-none">My library</h1><button type="button" onClick={storage.clearLibrary} className="rounded-full border border-border px-4 py-2 text-sm hover:border-primary" data-testid="button-clear-library">Clear library data</button></div><div className="mt-14"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Saved for later</p><h2 className="mt-1 font-display text-4xl">Favorites</h2></div><span className="font-mono-ui text-xs text-muted-foreground">{storage.favorites.length} titles</span></div>{storage.favorites.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-4 lg:grid-cols-6">{storage.favorites.map((item, i) => <ItemCard key={itemKey(item)} item={item} index={i} onFavorite={storage.toggleFavorite} favorite />)}</div> : <EmptyState title="Your shelves are quiet." copy="Save titles from discovery and they'll stay here, locally on this device." action={<Link href="/search" className="mt-6 inline-flex rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground" data-testid="link-library-search">Find something</Link>} />}</div><section className="mt-20"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Pick up where you left off</p><h2 className="mt-1 font-display text-4xl">Continue watching</h2></div><History className="h-5 w-5 text-muted-foreground" /></div>{continueItems.length ? <div className="space-y-3">{continueItems.slice(0, 5).map((item) => <WatchedRow key={watchKey(item, item.episodeId)} item={item} progress={storage.progress[watchKey(item, item.episodeId)]} onRemove={storage.removeWatched} />)}</div> : <p className="rounded-xl border border-dashed border-border p-8 text-sm text-muted-foreground">Start a title and your saved position will appear here.</p>}</section><section className="mt-20"><div className="mb-5 flex items-end justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">A little unfinished</p><h2 className="mt-1 font-display text-4xl">Recently watched</h2></div><History className="h-5 w-5 text-muted-foreground" /></div>{storage.watched.length ? <div className="space-y-3">{storage.watched.slice(0, 5).map((item) => <WatchedRow key={watchKey(item, item.episodeId)} item={item} progress={storage.progress[watchKey(item, item.episodeId)]} onRemove={storage.removeWatched} />)}</div> : <p className="rounded-xl border border-dashed border-border p-8 text-sm text-muted-foreground">Your watch history will appear here after you start a title.</p>}</section></div>;
}

function SettingsPage() {
  const storage = useVaultStorage();
  return <div className="mx-auto max-w-4xl px-5 py-12 pb-28 md:px-10 md:py-16"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">The quiet room</p><h1 className="mt-3 font-display text-7xl leading-none">Settings</h1><div className="mt-12 space-y-4"><SettingSection icon={storage.theme === 'dark' ? Moon : Sun} title="Appearance" copy="A small preference, remembered on this device."><div className="flex gap-2"><button type="button" onClick={() => storage.setTheme('light')} className={`rounded-full border px-4 py-2 text-sm ${storage.theme === 'light' ? 'border-primary bg-[hsl(var(--primary)/.1)]' : 'border-border'}`} data-testid="button-theme-light">Light</button><button type="button" onClick={() => storage.setTheme('dark')} className={`rounded-full border px-4 py-2 text-sm ${storage.theme === 'dark' ? 'border-primary bg-[hsl(var(--primary)/.1)]' : 'border-border'}`} data-testid="button-theme-dark">Dark</button></div></SettingSection><SettingSection icon={Tv} title="Playback" copy="Set the defaults for the next room."><div className="grid gap-4 sm:grid-cols-2"><label className="text-sm">Quality<select value={storage.settings.quality} onChange={(e) => storage.setSettings({ quality: e.target.value })} className="mt-2 block h-11 w-full rounded-xl border border-border bg-card px-3" data-testid="select-quality"><option value="auto">Auto</option><option value="1080p">1080p where available</option><option value="720p">720p</option></select></label><label className="text-sm">Language<select value={storage.settings.language} onChange={(e) => storage.setSettings({ language: e.target.value })} className="mt-2 block h-11 w-full rounded-xl border border-border bg-card px-3" data-testid="select-language"><option>Original</option><option>English</option><option>Spanish</option></select></label></div><label className="mt-4 flex items-center gap-3 text-sm"><input type="checkbox" checked={storage.settings.autoplay} onChange={(e) => storage.setSettings({ autoplay: e.target.checked })} data-testid="checkbox-autoplay" />Autoplay when an authorized player supports it</label><label className="mt-3 flex items-center gap-3 text-sm"><input type="checkbox" checked={storage.settings.subtitles} onChange={(e) => storage.setSettings({ subtitles: e.target.checked })} data-testid="checkbox-subtitles" />Prefer subtitles</label></SettingSection><SettingSection icon={History} title="History controls" copy="Everything here is stored locally. Nothing is sent to StreamVault."><div className="flex flex-wrap gap-2"><button type="button" onClick={storage.clearHistory} className="rounded-full border border-border px-4 py-2 text-sm hover:border-primary" data-testid="button-settings-clear-history">Clear search history</button><button type="button" onClick={storage.clearWatched} className="rounded-full border border-border px-4 py-2 text-sm hover:border-primary" data-testid="button-settings-clear-watch-history">Clear watch history</button></div></SettingSection><SettingSection icon={ShieldCheck} title="About the source system" copy="StreamVault only displays routes returned by configured public metadata and approved media providers. Direct authorized media, permitted embeds, and official pages are always labeled. We do not extract hidden URLs, bypass controls, or make availability claims beyond the source response." /><SettingSection icon={Info} title="Privacy" copy="Favorites, progress, theme, and search history are stored locally in this browser. StreamVault does not require an account in this version and does not upload your personal library." /><SettingSection icon={Info} title="StreamVault" copy="A private cinema journal for legal discovery. Content availability depends on each provider and its current permissions." /></div></div>;
}
function SettingSection({ icon: Icon, title, copy, children }: { icon: typeof Sun; title: string; copy: string; children?: ReactNode }) {
  return <section className="rounded-2xl border border-border bg-card p-5 md:p-7"><div className="flex gap-4"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[hsl(var(--primary)/.1)] text-primary"><Icon className="h-5 w-5" /></div><div className="flex-1"><h2 className="font-display text-3xl">{title}</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{copy}</p>{children && <div className="mt-5">{children}</div>}</div></div></section>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={Home} /><Route path="/search" component={SearchPage} /><Route path="/title/:source/:id" component={DetailPage} /><Route path="/watch/:source/:id" component={WatchPage} /><Route path="/library" component={LibraryPage} /><Route path="/settings" component={SettingsPage} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}
function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><Shell><Router /></Shell><Toaster /></TooltipProvider></QueryClientProvider>;
}
export default App;