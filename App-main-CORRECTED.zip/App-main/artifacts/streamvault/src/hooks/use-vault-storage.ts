import { useCallback, useEffect, useState } from 'react';
import type { ContentItem } from '@workspace/api-client-react';

const keys = {
  favorites: 'streamvault:favorites',
  history: 'streamvault:history',
  watched: 'streamvault:watched',
  progress: 'streamvault:progress',
  theme: 'streamvault:theme',
  playback: 'streamvault:playback',
} as const;

function read<T>(key: string, fallback: T): T {
  try { return JSON.parse(localStorage.getItem(key) || '') as T; } catch { return fallback; }
}
function write(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private browsing */ }
}

export type VaultSettings = { autoplay: boolean; quality: string; subtitles: boolean; language: string };
export type PlaybackProgress = {
  position: number;
  updatedAt: string;
  episodeId?: string;
  season?: number;
  episodeNumber?: number;
  duration?: number;
};
export type WatchedItem = ContentItem & {
  watchedAt: string;
  episodeId?: string;
  season?: number;
  episodeNumber?: number;
};

function normalizeProgress(value: Record<string, PlaybackProgress | number>) {
  return Object.fromEntries(
    Object.entries(value).map(([key, entry]) => [
      key,
      typeof entry === 'number'
        ? { position: entry, updatedAt: new Date(0).toISOString() }
        : entry,
    ]),
  ) as Record<string, PlaybackProgress>;
}

export function useVaultStorage() {
  const [favorites, setFavorites] = useState<ContentItem[]>(() => read(keys.favorites, []));
  const [history, setHistory] = useState<string[]>(() => read(keys.history, []));
  const [watched, setWatched] = useState<WatchedItem[]>(() => read(keys.watched, []));
  const [progress, setProgress] = useState<Record<string, PlaybackProgress>>(() => normalizeProgress(read(keys.progress, {})));
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => read(keys.theme, 'light'));
  const [settings, setSettingsState] = useState<VaultSettings>(() => read(keys.playback, { autoplay: true, quality: 'auto', subtitles: false, language: 'Original' }));

  useEffect(() => {
    write(keys.favorites, favorites);
    document.documentElement.classList.toggle('dark', theme === 'dark');
    write(keys.theme, theme);
  }, [favorites, theme]);
  useEffect(() => write(keys.history, history), [history]);
  useEffect(() => write(keys.watched, watched), [watched]);
  useEffect(() => write(keys.progress, progress), [progress]);
  useEffect(() => write(keys.playback, settings), [settings]);

  const toggleFavorite = useCallback((item: ContentItem) => {
    setFavorites((items) => items.some((x) => x.source === item.source && x.id === item.id)
      ? items.filter((x) => !(x.source === item.source && x.id === item.id))
      : [item, ...items]);
  }, []);
  const addSearch = useCallback((query: string) => {
    const clean = query.trim();
    if (!clean) return;
    setHistory((items) => [clean, ...items.filter((x) => x.toLowerCase() !== clean.toLowerCase())].slice(0, 8));
  }, []);
  const clearHistory = useCallback(() => setHistory([]), []);
  const clearWatched = useCallback(() => {
    setWatched([]);
    setProgress({});
  }, []);
  const markWatched = useCallback((item: ContentItem, context?: Pick<WatchedItem, 'episodeId' | 'season' | 'episodeNumber'>) => {
    setWatched((items) => [
      { ...item, ...context, watchedAt: new Date().toISOString() },
      ...items.filter((x) => !(x.id === item.id && x.source === item.source && x.episodeId === context?.episodeId)),
    ].slice(0, 20));
  }, []);
  const removeWatched = useCallback((item: WatchedItem) => {
    setWatched((items) => items.filter((x) => !(x.id === item.id && x.source === item.source && x.episodeId === item.episodeId)));
    const key = item.episodeId ? `${item.source}:${item.id}:episode:${item.episodeId}` : `${item.source}:${item.id}`;
    setProgress((items) => {
      const next = { ...items };
      delete next[key];
      return next;
    });
  }, []);
  const setWatchProgress = useCallback((key: string, position: number, metadata?: Omit<PlaybackProgress, 'position' | 'updatedAt'>) => {
    setProgress((items) => ({ ...items, [key]: { ...items[key], ...metadata, position, updatedAt: new Date().toISOString() } }));
  }, []);
  const clearLibrary = useCallback(() => {
    setFavorites([]);
    setWatched([]);
    setProgress({});
  }, []);
  const setTheme = useCallback((value: 'light' | 'dark') => setThemeState(value), []);
  const setSettings = useCallback((patch: Partial<VaultSettings>) => setSettingsState((value) => ({ ...value, ...patch })), []);

  return { favorites, history, watched, progress, theme, settings, toggleFavorite, addSearch, clearHistory, clearWatched, clearLibrary, removeWatched, markWatched, setWatchProgress, setTheme, setSettings };
}