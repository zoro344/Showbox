# StreamVault

StreamVault is a mobile-first legal streaming discovery and playback browser. It combines metadata from TVmaze and Jikan/MyAnimeList with public-domain / explicitly licensed media from Internet Archive's official APIs and file listings.

## Legal source policy

- **TVmaze** is used for public metadata only. StreamVault never treats TVmaze as a video host; it presents the official TVmaze page as the viewing route.
- **Jikan / MyAnimeList** is used for anime metadata and images. Jikan/MyAnimeList is not treated as a video host; playback remains an official-source handoff.
- **Internet Archive** is used through its official Advanced Search, Metadata, image, item, and file endpoints. Direct playback is returned only when the item rights metadata explicitly includes public-domain or Creative Commons language. Otherwise the app opens the official item page.
- The playback system distinguishes `direct`, `embed`, and `official-page` options. It uses the browser's native HTML5 player for authorized media (including browser-supported HLS), accepts subtitle tracks only when supplied by the provider, and falls back to the official page when embedding is unavailable. It does not scrape piracy sites, extract hidden URLs, bypass DRM/authentication/paywalls/geo-restrictions, or re-host content.
- Provider URLs are validated on the server against approved HTTPS domains before they reach the client.

## Run on Replit

1. Start the `artifacts/api-server: API Server` workflow.
2. Start the `artifacts/streamvault: web` workflow.
3. Open the web preview. Replit supplies `PORT` and `BASE_PATH` automatically.

This version does not need an account, database, or API key. TVmaze, Jikan/MyAnimeList, and Internet Archive are accessed through public endpoints. Favorites, search history, watched titles, episode-aware playback progress, theme, and playback settings are stored in the browser's localStorage on the device being used.

## Use from Android

Open the Replit preview URL in Chrome on your phone. You can use the browser menu's **Add to Home screen** option for an app-like shortcut. No Android Studio, emulator, or computer is required.

## Project map

- `src/App.tsx` — routes, responsive shell, discovery, search, details, episode guide, player, library, and settings.
- `src/hooks/use-vault-storage.ts` — local-only user state, episode-aware progress, and library clearing.
- `../api-server/src/services/catalog.ts` — configurable provider abstraction and legal source adapters.
- `../api-server/src/routes/catalog.ts` — typed REST endpoints.
- `../../lib/api-spec/openapi.yaml` — source of truth for the generated API contract.