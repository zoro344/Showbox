import { Router, type IRouter } from "express";
import {
  GetContentDetailsParams,
  GetContentDetailsResponse,
  GetContentEpisodesParams,
  GetContentEpisodesQueryParams,
  GetContentEpisodesResponse,
  GetHomeFeedResponse,
  GetPlaybackOptionsParams,
  GetPlaybackOptionsQueryParams,
  GetPlaybackOptionsResponse,
  SearchCatalogQueryParams,
  SearchCatalogResponse,
} from "@workspace/api-zod";
import {
  getDetails,
  getEpisodes,
  getHomeFeed,
  getPlaybackOptions,
  searchCatalog,
} from "../services/catalog";

const router: IRouter = Router();

router.get("/catalog/home", async (req, res) => {
  try {
    const feed = await getHomeFeed();
    res.json(GetHomeFeedResponse.parse(feed));
  } catch (error) {
    req.log.error({ err: error }, "Catalog home request failed");
    res
      .status(502)
      .json({ error: "Approved content sources are unavailable", code: "PROVIDER_UNAVAILABLE" });
  }
});

router.get("/catalog/search", async (req, res) => {
  const parsed = SearchCatalogQueryParams.safeParse({
    query: req.query.query,
    type: req.query.type,
    genre: req.query.genre,
  });
  if (!parsed.success) {
    res.status(400).json({ error: "Enter a valid search query", code: "INVALID_SEARCH" });
    return;
  }
  try {
    const results = await searchCatalog(
      parsed.data.query,
      parsed.data.type,
      parsed.data.genre,
    );
    res.json(SearchCatalogResponse.parse(results));
  } catch (error) {
    req.log.error({ err: error }, "Catalog search request failed");
    res
      .status(502)
      .json({ error: "Approved content sources are unavailable", code: "PROVIDER_UNAVAILABLE" });
  }
});

router.get("/catalog/:source/:id", async (req, res) => {
  const parsed = GetContentDetailsParams.safeParse({
    source: req.params.source,
    id: req.params.id,
  });
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid content reference", code: "INVALID_CONTENT" });
    return;
  }
  try {
    const detail = await getDetails(parsed.data.source, parsed.data.id);
    if (!detail) {
      res.status(404).json({ error: "Content was not found", code: "CONTENT_NOT_FOUND" });
      return;
    }
    res.json(GetContentDetailsResponse.parse(detail));
  } catch (error) {
    req.log.error({ err: error }, "Catalog details request failed");
    res
      .status(502)
      .json({ error: "The approved content source is unavailable", code: "PROVIDER_UNAVAILABLE" });
  }
});

router.get("/catalog/:source/:id/episodes", async (req, res) => {
  const path = GetContentEpisodesParams.safeParse({
    source: req.params.source,
    id: req.params.id,
  });
  const query = GetContentEpisodesQueryParams.safeParse({
    season: req.query.season,
  });
  if (!path.success || !query.success) {
    res.status(400).json({ error: "Invalid episode reference", code: "INVALID_EPISODE" });
    return;
  }
  try {
    const episodes = await getEpisodes(path.data.source, path.data.id, query.data.season);
    res.json(GetContentEpisodesResponse.parse(episodes));
  } catch (error) {
    req.log.error({ err: error }, "Catalog episodes request failed");
    res
      .status(502)
      .json({ error: "The approved content source is unavailable", code: "PROVIDER_UNAVAILABLE" });
  }
});

router.get("/catalog/:source/:id/playback", async (req, res) => {
  const path = GetPlaybackOptionsParams.safeParse({
    source: req.params.source,
    id: req.params.id,
  });
  const query = GetPlaybackOptionsQueryParams.safeParse({
    season: req.query.season,
    episode: req.query.episode,
  });
  if (!path.success || !query.success) {
    res.status(400).json({ error: "Invalid playback reference", code: "INVALID_PLAYBACK" });
    return;
  }
  try {
    const options = await getPlaybackOptions(
      path.data.source,
      path.data.id,
      query.data.season,
      query.data.episode,
    );
    res.json(GetPlaybackOptionsResponse.parse(options));
  } catch (error) {
    req.log.error({ err: error }, "Catalog playback request failed");
    res
      .status(502)
      .json({ error: "Playback options are unavailable", code: "PROVIDER_UNAVAILABLE" });
  }
});

export default router;