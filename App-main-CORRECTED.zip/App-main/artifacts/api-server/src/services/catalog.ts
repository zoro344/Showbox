import type { ContentSource as SourceName } from "@workspace/api-zod";

type ContentType = "movie" | "series" | "documentary" | "short";
type PlaybackKind = "direct" | "embed" | "official-page";

export type ProviderRef = {
  name: string;
  source: SourceName;
  url: string;
  permission: string;
};

export type ContentItem = {
  id: string;
  source: SourceName;
  type: ContentType;
  title: string;
  year: number | null;
  posterUrl: string | null;
  backdropUrl: string | null;
  genres: string[];
  rating: number | null;
  duration: number | null;
  provider: ProviderRef;
};

export type ContentDetail = ContentItem & {
  description: string;
  cast: string[];
  crew: string[];
  seasons: number[];
  sources: ProviderRef[];
};

export type Episode = {
  id: string;
  source: SourceName;
  season: number;
  number: number;
  title: string;
  description: string;
  thumbnailUrl: string | null;
  duration: number | null;
  airdate: string | null;
  officialSource: ProviderRef;
};

export type PlaybackOption = {
  id: string;
  label: string;
  kind: PlaybackKind;
  url: string;
  mimeType: string | null;
  provider: ProviderRef;
  isEmbeddable: boolean;
  licenseNote: string;
  subtitles?: Array<{
    label: string;
    language: string;
    url: string;
  }>;
};

export type CatalogRow = {
  title: string;
  items: ContentItem[];
};

export type HomeFeed = {
  featured: ContentDetail;
  rows: CatalogRow[];
  sources: ProviderRef[];
};

export interface ContentProvider {
  id: SourceName;
  name: string;
  provider: ProviderRef;
  search(query: string): Promise<ContentItem[]>;
  getDetails(id: string): Promise<ContentDetail | null>;
  getEpisodes(id: string, season?: number): Promise<Episode[]>;
  getPlaybackOptions(
    id: string,
    season?: number,
    episode?: number,
  ): Promise<PlaybackOption[]>;
  getCatalogPage?(page?: number): Promise<ContentItem[]>;
  getTopAnime?(): Promise<ContentItem[]>;
};

const TVMAZE_API = "https://api.tvmaze.com";
const JIKAN_API = "https://api.jikan.moe/v4";
const TVMAZE_PERMISSION =
  "Metadata from TVmaze's public API. TVmaze does not host or authorize video playback.";
const JIKAN_PERMISSION =
  "Metadata from Jikan's public MyAnimeList API. Jikan and MyAnimeList do not authorize or host video playback for StreamVault.";
const INTERNET_ARCHIVE_PERMISSION =
  "Internet Archive's official metadata and file endpoints. Direct media is exposed only when the item declares public-domain or an explicit Creative Commons license.";

function safeUrl(value: unknown, approved: (hostname: string) => boolean) {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !approved(url.hostname)) return null;
    return url.toString();
  } catch {
    return null;
  }
}

function tvMazeUrl(value: unknown) {
  return safeUrl(
    value,
    (hostname) => hostname === "www.tvmaze.com" || hostname === "static.tvmaze.com",
  );
}

function jikanUrl(value: unknown) {
  return safeUrl(value, (hostname) => hostname === "myanimelist.net" || hostname === "www.myanimelist.net");
}

function jikanImageUrl(value: unknown) {
  return safeUrl(
    value,
    (hostname) =>
      hostname === "cdn.myanimelist.net" ||
      hostname.endsWith(".cdn.myanimelist.net"),
  );
}

function archiveUrl(value: unknown) {
  return safeUrl(
    value,
    (hostname) =>
      hostname === "archive.org" ||
      hostname === "www.archive.org" ||
      hostname.endsWith(".archive.org"),
  );
}

function stripHtml(value: unknown) {
  if (typeof value !== "string") return "";
  return value
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .trim();
}

async function fetchJson<T>(url: string, headers: Record<string, string> = {}): Promise<T> {
  const response = await fetch(url, {
    headers: { accept: "application/json", ...headers },
    signal: AbortSignal.timeout(8_000),
  });
  if (!response.ok) {
    throw new Error(`Provider returned ${response.status}`);
  }
  return (await response.json()) as T;
}

async function fetchJsonWithRetry<T>(url: string, attempts = 3): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      return await fetchJson<T>(url);
    } catch (error) {
      lastError = error;
      if (attempt < attempts - 1) {
        await new Promise((resolve) => setTimeout(resolve, 250 * (attempt + 1)));
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Provider request failed");
}

type TvMazeShow = {
  id: number;
  name: string;
  type?: string;
  premiered?: string | null;
  genres?: string[];
  rating?: { average?: number | null };
  runtime?: number | null;
  averageRuntime?: number | null;
  image?: { medium?: string | null; original?: string | null } | null;
  summary?: string | null;
  url?: string;
  officialSite?: string | null;
  _embedded?: {
    cast?: Array<{ person?: { name?: string } }>;
    crew?: Array<{ person?: { name?: string }; type?: string }>;
  };
};

type TvMazeEpisode = {
  id: number;
  season: number;
  number: number;
  name: string;
  summary?: string | null;
  image?: { medium?: string | null } | null;
  runtime?: number | null;
  airdate?: string | null;
  url?: string;
};

function tvMazeProvider(show: TvMazeShow): ProviderRef {
  const url = tvMazeUrl(show.url) ?? `https://www.tvmaze.com/shows/${show.id}`;
  return {
    name: "TVmaze",
    source: "tvmaze",
    url,
    permission: TVMAZE_PERMISSION,
  };
}

function tvMazeItem(show: TvMazeShow): ContentItem {
  const provider = tvMazeProvider(show);
  return {
    id: String(show.id),
    source: "tvmaze",
    type: "series",
    title: show.name,
    year: show.premiered ? Number(show.premiered.slice(0, 4)) || null : null,
    posterUrl: tvMazeUrl(show.image?.medium) ?? tvMazeUrl(show.image?.original),
    backdropUrl: tvMazeUrl(show.image?.original) ?? tvMazeUrl(show.image?.medium),
    genres: Array.isArray(show.genres) ? show.genres : [],
    rating:
      typeof show.rating?.average === "number" ? show.rating.average : null,
    duration:
      typeof show.averageRuntime === "number"
        ? show.averageRuntime
        : typeof show.runtime === "number"
          ? show.runtime
          : null,
    provider,
  };
}

const tvMazeSource: ContentProvider = {
  id: "tvmaze",
  name: "tvmaze",
  provider: {
    name: "TVmaze",
    source: "tvmaze",
    url: "https://www.tvmaze.com/api",
    permission: TVMAZE_PERMISSION,
  },
  async search(query) {
    const data = await fetchJson<Array<{ show: TvMazeShow }>>(
      `${TVMAZE_API}/search/shows?q=${encodeURIComponent(query)}`,
    );
    return data.map((result) => tvMazeItem(result.show)).slice(0, 20);
  },
  async getCatalogPage(page = 0) {
    const shows = await fetchJson<TvMazeShow[]>(
      `${TVMAZE_API}/shows?page=${Math.max(0, Math.floor(page))}`,
    );
    return shows.map(tvMazeItem).filter((item): item is ContentItem => Boolean(item));
  },
  async getDetails(id) {
    const show = await fetchJson<TvMazeShow>(
      `${TVMAZE_API}/shows/${encodeURIComponent(id)}?embed[]=cast&embed[]=crew`,
    );
    const base = tvMazeItem(show);
    const seasons = await fetchJson<
      Array<{ number: number; episodeOrder?: number | null }>
    >(`${TVMAZE_API}/shows/${encodeURIComponent(id)}/seasons`);
    return {
      ...base,
      description: stripHtml(show.summary) || "No description provided.",
      cast: (show._embedded?.cast ?? [])
        .map((entry) => entry.person?.name)
        .filter((name): name is string => Boolean(name))
        .slice(0, 12),
      crew: (show._embedded?.crew ?? [])
        .map((entry) =>
          entry.person?.name ? `${entry.person.name} · ${entry.type ?? "Crew"}` : null,
        )
        .filter((name): name is string => Boolean(name))
        .slice(0, 8),
      seasons: seasons
        .map((season) => season.number)
        .filter((number) => Number.isInteger(number) && number > 0),
      sources: [base.provider],
    };
  },
  async getEpisodes(id, season) {
    const episodes = await fetchJson<TvMazeEpisode[]>(
      `${TVMAZE_API}/shows/${encodeURIComponent(id)}/episodes`,
    );
    return episodes
      .filter((episode) => season === undefined || episode.season === season)
      .map((episode) => {
        const officialSource: ProviderRef = {
          name: "TVmaze",
          source: "tvmaze",
          url:
            tvMazeUrl(episode.url) ??
            `https://www.tvmaze.com/episodes/${episode.id}`,
          permission: TVMAZE_PERMISSION,
        };
        return {
          id: String(episode.id),
          source: "tvmaze",
          season: episode.season,
          number: episode.number,
          title: episode.name,
          description: stripHtml(episode.summary) || "No episode description provided.",
          thumbnailUrl: tvMazeUrl(episode.image?.medium),
          duration:
            typeof episode.runtime === "number" ? episode.runtime : null,
          airdate: episode.airdate ?? null,
          officialSource,
        };
      });
  },
  async getPlaybackOptions(id) {
    const detail = await fetchJson<TvMazeShow>(
      `${TVMAZE_API}/shows/${encodeURIComponent(id)}`,
    );
    const provider = tvMazeProvider(detail);
    return [
      {
        id: `tvmaze-official-${id}`,
        label: "Open TVmaze show page",
        kind: "official-page",
        url: provider.url,
        mimeType: null,
        provider,
        isEmbeddable: false,
        licenseNote:
          "TVmaze supplies metadata only. Open the official page to review the show's authorized viewing links.",
      },
    ];
  },
};

type JikanAnime = {
  mal_id: number;
  url?: string;
  title: string;
  title_english?: string | null;
  type?: string | null;
  year?: number | null;
  synopsis?: string | null;
  score?: number | null;
  episodes?: number | null;
  duration?: string | null;
  images?: { jpg?: { image_url?: string; large_image_url?: string } };
  genres?: Array<{ name?: string }>;
  aired?: { from?: string | null };
  characters?: Array<{ character?: { name?: string } }>;
};

type JikanSearchResponse = { data?: JikanAnime[] };
type JikanEpisodesResponse = {
  data?: Array<{
    mal_id: number;
    url?: string;
    title?: string;
    synopsis?: string | null;
    duration?: number | null;
    aired?: string | null;
    images?: { jpg?: { image_url?: string } };
  }>;
};

function jikanProvider(id: number | string, url?: string): ProviderRef {
  return {
    name: "MyAnimeList via Jikan",
    source: "jikan",
    url: jikanUrl(url) ?? `https://myanimelist.net/anime/${encodeURIComponent(String(id))}`,
    permission: JIKAN_PERMISSION,
  };
}

function jikanItem(anime: JikanAnime): ContentItem | null {
  if (!anime.mal_id || !anime.title) return null;
  const provider = jikanProvider(anime.mal_id, anime.url);
  const isMovie = anime.type?.toLowerCase() === "movie";
  const date = anime.aired?.from ?? "";
  return {
    id: String(anime.mal_id),
    source: "jikan",
    type: isMovie ? "movie" : "series",
    title: anime.title_english || anime.title,
    year: anime.year ?? (date ? Number(date.slice(0, 4)) || null : null),
    posterUrl: jikanImageUrl(anime.images?.jpg?.large_image_url) ?? jikanImageUrl(anime.images?.jpg?.image_url),
    backdropUrl: jikanImageUrl(anime.images?.jpg?.large_image_url) ?? jikanImageUrl(anime.images?.jpg?.image_url),
    genres: (anime.genres ?? []).map((genre) => genre.name).filter((name): name is string => Boolean(name)),
    rating: typeof anime.score === "number" ? anime.score : null,
    duration: typeof anime.duration === "string" ? Number(anime.duration.match(/\d+/)?.[0] ?? 0) || null : null,
    provider,
  };
}

function parseJikanId(id: string) {
  if (!/^\d+$/.test(id)) throw new Error("Invalid Jikan content identifier");
  return id;
}

const jikanSource: ContentProvider = {
  id: "jikan",
  name: "jikan",
  provider: {
    name: "MyAnimeList via Jikan",
    source: "jikan",
    url: "https://jikan.moe/",
    permission: JIKAN_PERMISSION,
  },
  async getTopAnime() {
    const data = await fetchJsonWithRetry<JikanSearchResponse>(
      `${JIKAN_API}/top/anime?limit=20&sfw=true`,
    );
    return (data.data ?? [])
      .map((anime) => jikanItem(anime))
      .filter((item): item is ContentItem => Boolean(item));
  },
  async search(query) {
    try {
      const data = await fetchJsonWithRetry<JikanSearchResponse>(
        `${JIKAN_API}/anime?q=${encodeURIComponent(query)}&limit=20&sfw=true`,
      );
      return (data.data ?? [])
        .map((anime) => jikanItem(anime))
        .filter((item): item is ContentItem => Boolean(item));
    } catch (error) {
      if (!/^\d+$/.test(query.trim())) throw error;
      const detail = await fetchJsonWithRetry<{ data?: JikanAnime }>(
        `${JIKAN_API}/anime/${parseJikanId(query.trim())}`,
      );
      const item = detail.data ? jikanItem(detail.data) : null;
      return item ? [item] : [];
    }
  },
  async getDetails(id) {
    const anime = await fetchJsonWithRetry<{ data?: JikanAnime }>(
      `${JIKAN_API}/anime/${parseJikanId(id)}/full`,
    );
    const base = anime.data ? jikanItem(anime.data) : null;
    if (!base || !anime.data) return null;
    return {
      ...base,
      description: anime.data.synopsis?.trim() || "No description provided.",
      cast: (anime.data.characters ?? [])
        .map((entry) => entry.character?.name)
        .filter((name): name is string => Boolean(name))
        .slice(0, 12),
      crew: [],
      seasons: anime.data.type?.toLowerCase() === "movie" ? [] : [1],
      sources: [base.provider],
    };
  },
  async getEpisodes(id) {
    const data = await fetchJsonWithRetry<JikanEpisodesResponse>(
      `${JIKAN_API}/anime/${parseJikanId(id)}/episodes?limit=100`,
    );
    return (data.data ?? []).map((episode) => ({
      id: String(episode.mal_id),
      source: "jikan" as const,
      season: 1,
      number: episode.mal_id,
      title: episode.title ?? `Episode ${episode.mal_id}`,
      description: episode.synopsis?.trim() || "No episode description provided.",
      thumbnailUrl: jikanImageUrl(episode.images?.jpg?.image_url),
      duration: episode.duration ?? null,
      airdate: episode.aired ?? null,
      officialSource: jikanProvider(id),
    }));
  },
  async getPlaybackOptions(id) {
    const provider = jikanProvider(parseJikanId(id));
    return [{
      id: `jikan-official-${id}`,
      label: "Open MyAnimeList title page",
      kind: "official-page",
      url: provider.url,
      mimeType: null,
      provider,
      isEmbeddable: false,
      licenseNote:
        "Jikan and MyAnimeList supply metadata only. Open the official page to review authorized viewing availability.",
    }];
  },
};

type ArchiveDoc = {
  identifier?: string;
  title?: string;
  description?: string;
  year?: string | number;
  date?: string;
  creator?: string | string[];
  subject?: string | string[];
  collection?: string | string[];
};

type ArchiveSearchResponse = {
  response?: { docs?: ArchiveDoc[] };
};

type ArchiveMetadata = {
  metadata?: ArchiveDoc & {
    rights?: string;
    licenseurl?: string;
    mediatype?: string;
  };
  files?: Array<{
    name?: string;
    format?: string;
    size?: string;
  }>;
};

function firstString(value: unknown) {
  if (Array.isArray(value)) return value.find((entry) => typeof entry === "string") ?? "";
  return typeof value === "string" ? value : "";
}

function archiveProvider(identifier: string): ProviderRef {
  return {
    name: "Internet Archive",
    source: "internet-archive",
    url: `https://archive.org/details/${encodeURIComponent(identifier)}`,
    permission: INTERNET_ARCHIVE_PERMISSION,
  };
}

function archiveImage(identifier: string) {
  return `https://archive.org/services/img/${encodeURIComponent(identifier)}`;
}

function archiveItem(doc: ArchiveDoc): ContentItem | null {
  if (!doc.identifier || !doc.title) return null;
  const provider = archiveProvider(doc.identifier);
  const yearValue = String(doc.year ?? doc.date ?? "").slice(0, 4);
  const subjects = firstStringArray(doc.subject)
    .map((subject) => subject.replace(/^[-\s]+/, "").trim())
    .filter(Boolean)
    .slice(0, 4);
  return {
    id: doc.identifier,
    source: "internet-archive",
    type: "movie",
    title: doc.title,
    year: /^\d{4}$/.test(yearValue) ? Number(yearValue) : null,
    posterUrl: archiveImage(doc.identifier),
    backdropUrl: archiveImage(doc.identifier),
    genres: subjects.length ? subjects : ["Public domain"],
    rating: null,
    duration: null,
    provider,
  };
}

function firstStringArray(value: unknown) {
  if (Array.isArray(value)) {
    return value.filter((entry): entry is string => typeof entry === "string");
  }
  return typeof value === "string" ? [value] : [];
}

function hasExplicitRights(metadata: ArchiveMetadata["metadata"]) {
  const rights = `${metadata?.rights ?? ""} ${metadata?.licenseurl ?? ""}`.toLowerCase();
  return (
    rights.includes("public domain") ||
    rights.includes("publicdomain") ||
    rights.includes("creativecommons.org")
  );
}

const internetArchiveSource: ContentProvider = {
  id: "internet-archive",
  name: "internet-archive",
  provider: {
    name: "Internet Archive",
    source: "internet-archive",
    url: "https://archive.org/developers",
    permission: INTERNET_ARCHIVE_PERMISSION,
  },
  async search(query) {
    const params = new URLSearchParams({
      q: `${query} AND mediatype:movies`,
      fl: "identifier,title,description,year,date,creator,subject,collection",
      rows: "20",
      page: "1",
      output: "json",
    });
    const data = await fetchJson<ArchiveSearchResponse>(
      `https://archive.org/advancedsearch.php?${params.toString()}`,
    );
    return (data.response?.docs ?? [])
      .map(archiveItem)
      .filter((item): item is ContentItem => Boolean(item));
  },
  async getDetails(id) {
    const data = await fetchJson<ArchiveMetadata>(
      `https://archive.org/metadata/${encodeURIComponent(id)}`,
    );
    const metadata = data.metadata;
    if (!metadata?.identifier && !id) return null;
    const provider = archiveProvider(id);
    const base: ContentItem = {
      id,
      source: "internet-archive",
      type: metadata?.mediatype === "collection" ? "documentary" : "movie",
      title: metadata?.title ?? id,
      year: /^\d{4}$/.test(String(metadata?.year ?? metadata?.date ?? "").slice(0, 4))
        ? Number(String(metadata?.year ?? metadata?.date).slice(0, 4))
        : null,
      posterUrl: archiveImage(id),
      backdropUrl: archiveImage(id),
      genres: firstStringArray(metadata?.subject).slice(0, 8),
      rating: null,
      duration: null,
      provider,
    };
    return {
      ...base,
      description: stripHtml(metadata?.description) || "No description provided.",
      cast: firstStringArray(metadata?.creator).slice(0, 12),
      crew: [],
      seasons: [],
      sources: [provider],
    };
  },
  async getEpisodes() {
    return [];
  },
  async getPlaybackOptions(id) {
    const data = await fetchJson<ArchiveMetadata>(
      `https://archive.org/metadata/${encodeURIComponent(id)}`,
    );
    const provider = archiveProvider(id);
    const options: PlaybackOption[] = [];
    if (hasExplicitRights(data.metadata)) {
      for (const file of data.files ?? []) {
        const name = file.name ?? "";
        const lower = name.toLowerCase();
        const mimeType =
          lower.endsWith(".mp4")
            ? "video/mp4"
            : lower.endsWith(".webm")
              ? "video/webm"
              : lower.endsWith(".m3u8")
                ? "application/vnd.apple.mpegurl"
                : null;
        if (!mimeType || name.includes("_files.xml") || name.includes(".torrent")) {
          continue;
        }
        const url = archiveUrl(
          `https://archive.org/download/${encodeURIComponent(id)}/${name
            .split("/")
            .map(encodeURIComponent)
            .join("/")}`,
        );
        if (!url) continue;
        options.push({
          id: `ia-${id}-${name}`,
          label: `${file.format ?? mimeType} · ${name.split("/").pop()}`,
          kind: "direct",
          url,
          mimeType,
          provider,
          isEmbeddable: true,
          licenseNote:
            "Direct playback is shown because this item declares public-domain or Creative Commons rights in Internet Archive metadata.",
        });
        if (options.length >= 4) break;
      }
    }
    if (!options.length) {
      options.push({
        id: `ia-official-${id}`,
        label: "Open Internet Archive item",
        kind: "official-page",
        url: provider.url,
        mimeType: null,
        provider,
        isEmbeddable: false,
        licenseNote:
          "No directly playable file with explicit reuse rights was found. Review the official item page and its rights information.",
      });
    }
    return options;
  },
};

export const providerRegistry: Partial<Record<SourceName, ContentProvider>> = {
  tvmaze: tvMazeSource,
  jikan: jikanSource,
  "internet-archive": internetArchiveSource,
};

function sourceFor(name: SourceName): ContentProvider {
  const provider = providerRegistry[name];
  if (!provider) throw new Error(`Unsupported content source: ${name}`);
  return provider;
}

async function optional<T>(action: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await action();
  } catch (error) {
    console.warn(
      `[catalog] provider unavailable: ${error instanceof Error ? error.message : String(error)}`,
    );
    return fallback;
  }
}

export async function searchCatalog(query: string, type?: ContentType, genre?: string) {
  const clean = query.trim();
  if (!clean) return [];

  const results = await Promise.allSettled([
    tvMazeSource.search(clean),
    jikanSource.search(clean),
    internetArchiveSource.search(clean),
  ]);

  const combined = results.flatMap((result) =>
    result.status === "fulfilled" ? result.value : [],
  );

  return combined
    .filter((item) => !type || item.type === type)
    .filter(
      (item) =>
        !genre ||
        item.genres.some((itemGenre) =>
          itemGenre.toLowerCase().includes(genre.toLowerCase()),
        ),
    )
    .slice(0, 36);
}

export async function getDetails(source: SourceName, id: string) {
  return sourceFor(source).getDetails(id);
}

export async function getEpisodes(source: SourceName, id: string, season?: number) {
  return sourceFor(source).getEpisodes(id, season);
}

export async function getPlaybackOptions(
  source: SourceName,
  id: string,
  season?: number,
  episode?: number,
) {
  return sourceFor(source).getPlaybackOptions(id, season, episode);
}

export async function getHomeFeed(): Promise<HomeFeed> {
  // These are real catalog endpoints. There is deliberately no hard-coded
  // title list and no fake poster/video fallback.
  const [tvmaze, jikan, archive] = await Promise.all([
    optional(() => tvMazeSource.getCatalogPage(0), []),
    optional(() => jikanSource.getTopAnime(), []),
    optional(() => internetArchiveSource.search("public domain"), []),
  ]);

  const combined = [...tvmaze, ...jikan, ...archive];
  if (!combined.length) {
    throw new Error("No catalog provider returned content");
  }

  const featuredCandidate = tvmaze[0] ?? jikan[0] ?? archive[0];
  const featured =
    (await optional(
      () => sourceFor(featuredCandidate.source).getDetails(featuredCandidate.id),
      null,
    )) ?? {
      ...featuredCandidate,
      description: "Open this title for the latest metadata and approved viewing routes.",
      cast: [],
      crew: [],
      seasons: [],
      sources: [featuredCandidate.provider],
    };

  return {
    featured,
    rows: [
      { title: "TVmaze catalog", items: tvmaze.slice(0, 20) },
      { title: "Top anime", items: jikan.slice(0, 20) },
      { title: "Public-domain movies", items: archive.slice(0, 20) },
    ].filter((row) => row.items.length > 0),
    sources: [tvMazeSource.provider, jikanSource.provider, internetArchiveSource.provider],
  };
}
