---
name: OpenAPI Zod barrel collisions
description: Generated Orval Zod schemas can collide with generated TypeScript parameter types when both are star-exported.
---

When an OpenAPI route has path and query parameters, Orval may emit the same `*Params` identifier in both `generated/api.ts` and `generated/types/`. Keep the public Zod barrel explicit and type-only for generated domain types, excluding colliding parameter names.

**Why:** Codegen can succeed while the chained workspace typecheck fails with TS2308.

**How to apply:** After every OpenAPI codegen run, check the Zod barrel and preserve the explicit export list if Orval rewrites the generated types index.