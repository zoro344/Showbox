---
name: Provider connectivity verification
description: Durable verification rules and current upstream behavior for StreamVault metadata providers.
---

Provider integrations must be reported in two dimensions: wired in code and currently reachable/authenticated in live requests. A configured secret can still be rejected, and one endpoint can work while another endpoint is rate-limited or unavailable.

**Why:** StreamVault needs to distinguish metadata discovery from legal playback authorization, and provider failures must not be hidden by the unified catalog fallback.

**How to apply:** When auditing or changing providers, test a representative search and detail request, record the upstream status without exposing credentials, and keep partial-provider failure graceful. Treat real image URLs as payload evidence, not as proof that video is streamable.