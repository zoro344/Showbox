# StreamVault

StreamVault is a mobile-first legal streaming discovery browser with metadata, official-source handoffs, and rights-aware public-domain playback.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/streamvault run dev` — run the StreamVault web app
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Where things live

- `artifacts/streamvault/src/App.tsx` — frontend routes and OTT-style interface
- `artifacts/streamvault/src/hooks/use-vault-storage.ts` — localStorage-backed favorites, history, settings, and progress
- `artifacts/api-server/src/services/catalog.ts` — provider registry for TVmaze, Jikan/MyAnimeList, and Internet Archive
- `artifacts/api-server/src/routes/catalog.ts` — catalog REST routes
- `lib/api-spec/openapi.yaml` — API contract source of truth

## Architecture decisions

- Metadata and playback sources are separate concepts; TVmaze and Jikan provide metadata and official links, while Internet Archive can provide direct playback only when rights metadata is explicit.
- Providers are modeled behind a unified source interface and registry so additional authorized APIs can be added without coupling the UI to a specific catalog.
- No user account or database is required for the first version; private library state stays in browser localStorage.
- Only HTTPS URLs from approved provider domains are returned for external media and official-page actions.

## Product

- Mobile-first home discovery with featured content, horizontal shelves, source transparency, and responsive navigation.
- Search with local search history and type/genre filters.
- Detail pages with metadata, cast/crew, seasons, episodes, and legal viewing options.
- Provider-aware playback for authorized direct media and official-page fallbacks.
- Local favorites, Continue Watching, recently watched, episode-aware watch progress, theme, and playback settings.
- Native browser playback for provider-authorized compatible media and provider-supplied subtitle tracks; unsupported or non-embeddable sources use official-source handoff.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
